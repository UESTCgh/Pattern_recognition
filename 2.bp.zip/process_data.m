function process_data(input_filename, output_filename)
    % 读取Excel文件
    data_l = readtable(input_filename);
    
    % 确认列的数量
    num_columns = width(data_l); 
    if num_columns == 11
        % 修改所有列名
        data_l.Properties.VariableNames(1:11) = {'Num', 'Gender', 'Origin', 'Height', 'Weight', 'ShoeSize', 'Score50m', 'Lungs', 'Color', 'Sport', 'Art'};
    else
        error('Number of new column names does not match the number of columns in the dataset.');
    end
    
    % 删除包含任何空白数据的整行
    data_l = rmmissing(data_l);
    
    % 过滤性别的数据（只保留合法值 0 和 1）
    data = data_l(data_l.Gender == 0 | data_l.Gender == 1, :);
    
    % 设定异常值的过滤阈值（对身高和体重的异常值进行过滤）
    height_mean = mean(data.Height, 'omitnan');
    height_std = std(data.Height, 'omitnan');
    weight_mean = mean(data.Weight, 'omitnan');
    weight_std = std(data.Weight, 'omitnan');
    
    height_threshold = 3;
    weight_threshold = 3;
    data = data(abs(data.Height - height_mean) <= height_threshold * height_std & ...
                abs(data.Weight - weight_mean) <= weight_threshold * weight_std, :);
    
    % 检查数据是否仍有足够的观测值
    if height(data) < 2 || sum(data.Gender == 1) < 1 || sum(data.Gender == 0) < 1
        error('Not enough observations after preprocessing. Please ensure your data is correctly preprocessed.');
    end
    
    % 保存过滤后的数据到新的Excel文件
    writetable(data, output_filename);
end
