
% 调用 process_data 函数
process_data('data.xlsx', 'filtered_data.xlsx');
% 加载处理过的数据
data = readtable('filtered_data.xlsx');

% 提取需要的特征列
% 使用花括号 {} 来提取列
features = data(:, {'Height', 'Weight', 'ShoeSize', 'Score50m'});

% 检查 features 是否为 table 类型
if ~istable(features)
    error('features must be a table.');
end

% 将 table 转换为数组
X = table2array(features);

% 提取标签列
Y = data.Gender;  % 直接使用 Gender 列作为标签，因为它已经是数值类型

% 初始化网络参数
inputSize = size(X, 2); % 输入层节点数（特征数）
hiddenSize = 4; % 隐藏层节点数
outputSize = 1; % 输出层节点数
learningRate = 0.1; % 学习率
maxEpochs = 1000; % 最大迭代次数

% 初始化权重和偏置
W1 = randn(hiddenSize, inputSize);
b1 = zeros(hiddenSize, 1);
W2 = randn(outputSize, hiddenSize);
b2 = zeros(outputSize, 1);

% 定义 sigmoid 激活函数及其导数
sigmoid = @(x) 1 ./ (1 + exp(-x));
sigmoidPrime = @(x) sigmoid(x) .* (1 - sigmoid(x));

% 交叉验证
k = 5; % 5 折交叉验证
indices = crossvalind('Kfold', length(Y), k);
SE = 0;
SP = 0;
ACC = 0;
AUC = 0;

for fold = 1:k
    testIdx = (indices == fold); trainIdx = ~testIdx;
    
    XTrain = X(trainIdx, :);
    yTrain = Y(trainIdx, :);
    XTest = X(testIdx, :);
    yTest = Y(testIdx, :);
    
    % 训练网络
    for epoch = 1:maxEpochs
        % 前向传播
        z1 = W1 * XTrain' + b1; % 输入到隐藏层
        a1 = sigmoid(z1); % 隐藏层激活
        z2 = W2 * a1 + b2; % 隐藏层到输出层
        a2 = sigmoid(z2); % 输出层激活
        
        % 计算输出层的误差
        error = a2 - yTrain';
        
        % 反向传播
        delta2 = error .* sigmoidPrime(z2);
        dW2 = delta2 * a1';
        db2 = sum(delta2, 2);
        
        delta1 = (W2' * delta2) .* sigmoidPrime(z1);
        dW1 = delta1 * XTrain;
        db1 = sum(delta1, 2);
        
        % 更新权重和偏置
        W2 = W2 - learningRate * dW2;
        b2 = b2 - learningRate * db2;
        W1 = W1 - learningRate * dW1;
        b1 = b1 - learningRate * db1;
    end
    
    % 计算训练集上的预测
    z1 = W1 * XTrain' + b1;
    a1 = sigmoid(z1);
    z2 = W2 * a1 + b2;
    a2Train = sigmoid(z2);
    
    % 计算测试集上的预测
    z1 = W1 * XTest' + b1;
    a1 = sigmoid(z1);
    z2 = W2 * a1 + b2;
    a2Test = sigmoid(z2);
    
    % 预测结果阈值化（假设 0.5 为阈值）
    predictionsTrain = a2Train > 0.5;
    predictionsTest = a2Test > 0.5;
        
    % 计算性能指标
    TP = sum(predictionsTest' == 1 & yTest == 1);
    FP = sum(predictionsTest' == 1 & yTest == 0);
    FN = sum(predictionsTest' == 0 & yTest == 1);
    TN = sum(predictionsTest' == 0 & yTest == 0);
    
    SE = SE + TP / (TP + FN);
    SP = SP + TN / (TN + FP);
    ACC = ACC + (TP + TN) / (TP + TN + FP + FN);
    
    % 计算 AUC
    [fpr, tpr, ~] = roc(yTest(:), a2Test(:));
    AUC = AUC + trapz(tpr, fpr);
    
    end % 结束交叉验证循环

    % 计算平均性能指标
    SE = SE / k;
    SP = SP / k;
    ACC = ACC / k;
    AUC = AUC / k;
    
    % 显示性能指标
    fprintf('Sensitivity (SE): %f\n', SE);
    fprintf('Specificity (SP): %f\n', SP);
    fprintf('Accuracy (ACC): %f\n', ACC);
    fprintf('AUC: %f\n', AUC);